# download dataset & extract to data folder
mkdir data -p
wget https://www.dropbox.com/s/tdknvkpz1jp6iuz/dsnet_datasets.zip
unzip dsnet_datasets.zip -d data
rm dsnet_datasets.zip
