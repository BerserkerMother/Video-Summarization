python src/pretrain_siamese.py --data data --dataset tvsum --d_model 512 --attention_dim 512 --num_heads 8 --num_layers 6 --dropout 0.5 --use_pos true --weight_decay 1e-5 --lr 5e-5 --epochs 100
