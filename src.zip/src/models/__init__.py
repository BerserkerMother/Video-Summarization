from .modeling_fine_tune import EncoderOnly
from .modeling_pre_train import MAE, Encoder
from .new_model import NewModel
from .second_new_model import SecNewModel
from .new_pre_train import NewMAE
